#!/bin/bash
#sed -i ''"$1"'s/Zabbix/Bankingmon/g' $2
first=`echo $1 | cut -d \: -f 1`
second=`echo $1 | cut -d \: -f 2`
sed -i ''"$second"'s/Zabbix/Bankingmon/g' $first

